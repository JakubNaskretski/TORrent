package com.tracker;

import javax.sound.midi.Track;

public class Main {

    public static void main(String[] args) {
	new Tracker(10000);
    }
}
